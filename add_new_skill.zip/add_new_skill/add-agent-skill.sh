#!/usr/bin/env bash
set -euo pipefail

# add-agent-skill.sh
#
# 用法：
#   add-agent-skill.sh <skill-source> [npx skills add options...]
#
# 示例：
#   add-agent-skill.sh https://github.com/anthropics/skills --skill frontend-design --copy
#
# 核心关系：
#   REAL_SKILLS_DIR   = 容器已经挂载、并且容器内 agent 实际读取的 skills 目录在宿主机上的路径
#   ~/.agents/skills  -> REAL_SKILLS_DIR
#
# 可选：
#   LINK_CLAUDE=1 时，也会维护：
#   ~/.claude/skills  -> REAL_SKILLS_DIR

REAL_SKILLS_DIR="${REAL_SKILLS_DIR:-/Users/rexxin/CHANGE_ME/container-mounted/skills}"
AGENTS_ROOT="${AGENTS_ROOT:-$HOME/.agents}"
CLAUDE_ROOT="${CLAUDE_ROOT:-$HOME/.claude}"
LINK_CLAUDE="${LINK_CLAUDE:-0}"

AGENTS_SKILLS_LINK="$AGENTS_ROOT/skills"
CLAUDE_SKILLS_LINK="$CLAUDE_ROOT/skills"

SKILL_SOURCE="${1:-}"

STATUS="SUCCESS"
FAIL_REASONS=()
WARNINGS=()
EXPECTED_SKILL=""

add_failure() {
  STATUS="FAILED"
  FAIL_REASONS+=("$*")
}

add_warning() {
  WARNINGS+=("$*")
}

print_result() {
  echo
  echo "============================================================"
  echo "RESULT: $STATUS"
  echo "============================================================"

  if [[ "$STATUS" == "FAILED" ]]; then
    echo
    echo "Failure reasons:"
    for reason in "${FAIL_REASONS[@]}"; do
      echo "  - $reason"
    done
  fi

  if [[ "${#WARNINGS[@]}" -gt 0 ]]; then
    echo
    echo "Warnings:"
    for warning in "${WARNINGS[@]}"; do
      echo "  - $warning"
    done
  fi

  echo
  echo "Summary:"
  echo "  Real skills directory:"
  echo "    ${REAL_SKILLS_DIR_RESOLVED:-$REAL_SKILLS_DIR}"
  echo
  echo "  Agents skills entry:"
  if [[ -e "$AGENTS_SKILLS_LINK" || -L "$AGENTS_SKILLS_LINK" ]]; then
    echo "    $AGENTS_SKILLS_LINK -> $(realpath "$AGENTS_SKILLS_LINK" 2>/dev/null || echo '<unresolved>')"
  else
    echo "    $AGENTS_SKILLS_LINK <missing>"
  fi

  if [[ -n "$EXPECTED_SKILL" ]]; then
    echo
    echo "  Expected skill:"
    echo "    $EXPECTED_SKILL"
  fi

  echo "============================================================"
}

die() {
  add_failure "$*"
  print_result
  exit 1
}

info() {
  echo
  echo "==> $*"
}

usage() {
  cat <<EOF
Usage:
  $(basename "$0") <skill-source> [npx skills add options...]

Examples:
  $(basename "$0") https://github.com/anthropics/skills --skill frontend-design --copy
  $(basename "$0") https://github.com/anthropics/skills --skill frontend-design

Environment variables:
  REAL_SKILLS_DIR  Container-mounted real skills directory on host
  AGENTS_ROOT      Default: ~/.agents
  LINK_CLAUDE      Default: 0. Set to 1 to also link ~/.claude/skills
  CLAUDE_ROOT      Default: ~/.claude

Current:
  REAL_SKILLS_DIR=$REAL_SKILLS_DIR
  AGENTS_ROOT=$AGENTS_ROOT
  LINK_CLAUDE=$LINK_CLAUDE
  CLAUDE_ROOT=$CLAUDE_ROOT
EOF
}

ensure_link() {
  local link_path="$1"
  local target_path="$2"
  local label="$3"

  mkdir -p "$(dirname "$link_path")"

  if [[ -L "$link_path" ]]; then
    local current_target
    current_target="$(realpath "$link_path")"

    if [[ "$current_target" == "$target_path" ]]; then
      echo "OK: $label already points to:"
      echo "  $current_target"
    else
      echo "Updating $label symlink:"
      echo "  old: $current_target"
      echo "  new: $target_path"
      rm "$link_path"
      ln -s "$target_path" "$link_path"
    fi
  elif [[ -e "$link_path" ]]; then
    die "$link_path exists but is not a symlink. Please inspect it before replacing it."
  else
    ln -s "$target_path" "$link_path"
    echo "Created $label symlink:"
    echo "  $link_path -> $target_path"
  fi

  if [[ ! -L "$link_path" ]]; then
    die "$label was expected to be a symlink, but it is not: $link_path"
  fi

  local final_target
  final_target="$(realpath "$link_path")"

  if [[ "$final_target" != "$target_path" ]]; then
    die "$label points to the wrong target. Expected: $target_path, actual: $final_target"
  fi
}

extract_expected_skill() {
  local args=("$@")
  local i=0

  while [[ "$i" -lt "${#args[@]}" ]]; do
    case "${args[$i]}" in
      --skill)
        if [[ $((i + 1)) -lt "${#args[@]}" ]]; then
          EXPECTED_SKILL="${args[$((i + 1))]}"
        fi
        ;;
      --skill=*)
        EXPECTED_SKILL="${args[$i]#--skill=}"
        ;;
    esac
    i=$((i + 1))
  done
}

if [[ -z "$SKILL_SOURCE" || "$SKILL_SOURCE" == "-h" || "$SKILL_SOURCE" == "--help" ]]; then
  usage
  exit 0
fi

shift
NPX_ARGS=("$@")
extract_expected_skill "${NPX_ARGS[@]}"

if [[ "$REAL_SKILLS_DIR" == *"CHANGE_ME"* ]]; then
  die "REAL_SKILLS_DIR is not configured. Set REAL_SKILLS_DIR to the container-mounted real skills directory."
fi

info "Checking node and npx"

command -v node >/dev/null 2>&1 || die "node not found"
command -v npx >/dev/null 2>&1 || die "npx not found"

echo "node: $(node -v)"
echo "npx:  $(npx --version)"

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [[ "$NODE_MAJOR" -lt 18 ]]; then
  add_warning "current Node is $(node -v), but skills CLI may require Node >= 18"
fi

info "Preparing real skills directory"

mkdir -p "$REAL_SKILLS_DIR"
mkdir -p "$AGENTS_ROOT"

REAL_SKILLS_DIR_RESOLVED="$(realpath "$REAL_SKILLS_DIR")"

echo "Real skills directory:"
echo "  $REAL_SKILLS_DIR_RESOLVED"

if [[ -L "$REAL_SKILLS_DIR" ]]; then
  add_warning "REAL_SKILLS_DIR itself is a symlink. For container usage, set it to the real mounted directory directly."
fi

info "Ensuring shared skills links"

ensure_link "$AGENTS_SKILLS_LINK" "$REAL_SKILLS_DIR_RESOLVED" "~/.agents/skills"

if [[ "$LINK_CLAUDE" == "1" ]]; then
  mkdir -p "$CLAUDE_ROOT"
  ensure_link "$CLAUDE_SKILLS_LINK" "$REAL_SKILLS_DIR_RESOLVED" "~/.claude/skills"
else
  echo "Skipping ~/.claude/skills link. Set LINK_CLAUDE=1 if you want Claude Code to share the same skills."
fi

info "Testing ~/.agents/skills write-through"

TEST_FILE="$AGENTS_SKILLS_LINK/__skill_symlink_test__"
touch "$TEST_FILE"

if [[ ! -f "$REAL_SKILLS_DIR_RESOLVED/__skill_symlink_test__" ]]; then
  rm -f "$TEST_FILE" "$REAL_SKILLS_DIR_RESOLVED/__skill_symlink_test__"
  die "write-through test failed: writing to ~/.agents/skills did not create a file in REAL_SKILLS_DIR"
fi

rm -f "$TEST_FILE" "$REAL_SKILLS_DIR_RESOLVED/__skill_symlink_test__"

echo "OK: writing to ~/.agents/skills lands in:"
echo "  $REAL_SKILLS_DIR_RESOLVED"

info "Running npx skills add"

echo "Command:"
printf '  npx skills add %q' "$SKILL_SOURCE"
for arg in "${NPX_ARGS[@]}"; do
  printf ' %q' "$arg"
done
echo
echo

if ! npx skills add "$SKILL_SOURCE" "${NPX_ARGS[@]}"; then
  die "npx skills add failed"
fi

info "Verifying ~/.agents/skills still points to the real skills directory"

if [[ ! -L "$AGENTS_SKILLS_LINK" ]]; then
  die "after installation, ~/.agents/skills is no longer a symlink. npx may have replaced it."
fi

POST_INSTALL_TARGET="$(realpath "$AGENTS_SKILLS_LINK")"
if [[ "$POST_INSTALL_TARGET" != "$REAL_SKILLS_DIR_RESOLVED" ]]; then
  die "after installation, ~/.agents/skills points to the wrong directory. Expected: $REAL_SKILLS_DIR_RESOLVED, actual: $POST_INSTALL_TARGET"
fi

echo "OK: ~/.agents/skills still points to:"
echo "  $POST_INSTALL_TARGET"

if [[ -n "$EXPECTED_SKILL" ]]; then
  info "Verifying expected skill was installed"

  if [[ -f "$REAL_SKILLS_DIR_RESOLVED/$EXPECTED_SKILL/SKILL.md" ]]; then
    echo "OK: found expected skill:"
    echo "  $REAL_SKILLS_DIR_RESOLVED/$EXPECTED_SKILL/SKILL.md"
  else
    die "expected skill was not found at $REAL_SKILLS_DIR_RESOLVED/$EXPECTED_SKILL/SKILL.md"
  fi
else
  add_warning "no --skill argument was provided, so the script cannot verify a specific installed skill directory"
fi

info "Listing global skills"

npx skills list -g || add_warning "npx skills list -g failed"

info "Checking real skills directory"

echo "Real directory:"
echo "  $REAL_SKILLS_DIR_RESOLVED"
echo

echo "Top-level entries:"
ls -la "$REAL_SKILLS_DIR_RESOLVED"

info "Checking for symlinks inside the real skills directory"

SYMLINKS_FOUND="$(find "$REAL_SKILLS_DIR_RESOLVED" -maxdepth 3 -type l -print || true)"

if [[ -n "$SYMLINKS_FOUND" ]]; then
  add_warning "symlinks found inside REAL_SKILLS_DIR. Container may not resolve them if targets are outside mounted paths. Reinstall with Copy mode if needed."
  echo "Warning: symlinks found:"
  echo "$SYMLINKS_FOUND"
else
  echo "OK: no symlinks found inside the first 3 levels of the skills directory."
fi

print_result

if [[ "$STATUS" == "FAILED" ]]; then
  exit 1
fi
