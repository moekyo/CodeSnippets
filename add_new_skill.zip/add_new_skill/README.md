# add-agent-skill

一个用于安装 Agent Skills 的小脚本说明。

这个脚本的作用是：把真正的技能文件放到一个容器也能访问的目录里，然后让本机的全局 skills 目录通过软链接指过去。

## 为什么需要这个脚本

有些 Agent 跑在容器里，容器访问不到宿主机默认的全局技能目录：

~/.agents/skills

所以不能简单把技能装到默认位置。

这个脚本使用的结构是：

~/.agents/skills -> REAL_SKILLS_DIR

其中：

REAL_SKILLS_DIR
  = 真正保存 skills 文件的目录
  = 应该是容器已经挂载、容器里的 Agent 也能访问到的目录

这样后续继续使用 npx skills add 安装技能时，技能实际会落到 REAL_SKILLS_DIR 里。

## 文件关系

默认维护：

~/.agents/skills
  -> REAL_SKILLS_DIR

可选维护：

~/.claude/skills
  -> REAL_SKILLS_DIR

只有设置 LINK_CLAUDE=1 时，才会处理 Claude Code 的 skills 目录。

## 基本用法

先给脚本加执行权限：

  chmod +x ./add-agent-skill.sh

安装技能：

  REAL_SKILLS_DIR="/path/to/container-mounted/skills" \
    ./add-agent-skill.sh https://github.com/anthropics/skills --skill frontend-design --copy

建议加 --copy。

原因是容器场景下，真实 skills 目录里最好放实际文件，不要放指向宿主机其他位置的软链接。

## 在 Desktop 上测试

可以先用 Desktop 沙盒目录测试，不影响真实的 ~/.agents/skills。

  TEST_ROOT="$HOME/Desktop/skills-test"
  TEST_HOME="$TEST_ROOT/test-home"
  TEST_REAL_SKILLS="$TEST_ROOT/real-skills"

  rm -rf "$TEST_ROOT"
  mkdir -p "$TEST_HOME/.agents" "$TEST_REAL_SKILLS"

  HOME="$TEST_HOME" \
  REAL_SKILLS_DIR="$TEST_REAL_SKILLS" \
  AGENTS_ROOT="$TEST_HOME/.agents" \
    ./add-agent-skill.sh https://github.com/anthropics/skills --skill frontend-design --copy

测试成功后，应该看到：

  RESULT: SUCCESS

并且应该满足：

  $TEST_HOME/.agents/skills -> $TEST_REAL_SKILLS
  $TEST_REAL_SKILLS/frontend-design/SKILL.md 存在
  $TEST_REAL_SKILLS 里面没有不必要的软链接

## 正式使用

把 REAL_SKILLS_DIR 换成真实的容器挂载 skills 目录：

  REAL_SKILLS_DIR="/你的/容器挂载/skills目录" \
    ./add-agent-skill.sh https://github.com/anthropics/skills --skill frontend-design --copy

如果你经常使用同一个目录，也可以把 REAL_SKILLS_DIR 写进 shell 配置里，例如 ~/.zshrc：

  export REAL_SKILLS_DIR="/你的/容器挂载/skills目录"

之后就可以直接运行：

  ./add-agent-skill.sh https://github.com/anthropics/skills --skill frontend-design --copy

## 怎么判断成功

脚本最后会输出统一结果。

成功时：

  RESULT: SUCCESS

失败时：

  RESULT: FAILED

并且会输出失败原因：

  Failure reasons:
    - ...

成功至少表示：

  1. REAL_SKILLS_DIR 已经创建或存在
  2. ~/.agents/skills 是软链接
  3. ~/.agents/skills 指向 REAL_SKILLS_DIR
  4. 写入 ~/.agents/skills 会实际写到 REAL_SKILLS_DIR
  5. npx skills add 执行成功
  6. 如果传了 --skill，脚本能在 REAL_SKILLS_DIR/<skill>/SKILL.md 找到技能文件

## 常见情况

如果 ~/.agents/skills 已经存在，并且是普通目录，不是软链接，脚本会停止，不会自动删除。

需要你先手动检查：

  ls -la ~/.agents/skills

确认可以替换后再自己备份或删除。

如果脚本提示 REAL_SKILLS_DIR 里面发现 symlink，这通常不是立即失败，但容器可能无法解析这些软链接。

这种情况下建议重新安装，并加上 --copy：

  ./add-agent-skill.sh <source> --skill <skill-name> --copy

## Claude Code 可选共享

默认不处理 Claude Code。

如果也想让 Claude Code 共用同一套 skills，可以这样运行：

  LINK_CLAUDE=1 \
  REAL_SKILLS_DIR="/path/to/container-mounted/skills" \
    ./add-agent-skill.sh https://github.com/anthropics/skills --skill frontend-design --copy

这样会额外维护：

  ~/.claude/skills -> REAL_SKILLS_DIR

如果你只需要 GitHub Copilot / OpenCode，就不要设置 LINK_CLAUDE=1。
